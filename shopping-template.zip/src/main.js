// Fetch the items from the JSON file
function loadItems() {
    return fetch("data/data.json")
        .then(response => response.json())
        .then(json => json.items);
}

// Update the list with the given items
function displayItem(items) {
    const container = document.querySelector('.items');
    container.innerHTML = items.map(item => creatHTMLString(item)).join('');
}
// Creat HTML list item from the given data item
function creatHTMLString(item) {
    return `
    <li class="item">
    <img src="${item.image}" alt="${item.type}" class="items__thumbnail">
    <span class="item__description">${item.gender}, ${item.size}</span>
    </li>
    `;
}

function setEventListener(items) {
    const logo = document.querySelector('.logo');
    const buttons = document.querySelector('.buttons');
    logo.addEventListener('click', () => displayItem(items));
    buttons.addEventListener('click', (event) => onButtonclick(event, items));
}

function onButtonclick(event, items) {
    const dataset = event.target.dataset;
    const key = dataset.key;
    const value = dataset.value;

    if (key === null || value === null) {
        return;
    }

    const filtered = items.filter(item => item[key] === value);
    displayItem(filtered);
    console.log(filtered);
}

loadItems()
    .then(items => {
        displayItem(items);
        setEventListener(items);
    })